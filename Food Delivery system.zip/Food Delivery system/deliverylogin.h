#ifndef DELIVERYLOGIN_H_INCLUDED
#define DELIVERYLOGIN_H_INCLUDED
int logind(char uname[],char pword[]);
int view_balance(char username[]);
int changexy(char username[],int x,int y);
int main_dl();


#endif // DELIVERYLOGIN_H_INCLUDED
