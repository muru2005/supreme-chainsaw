#ifndef RECCOMENDATION_H_INCLUDED
#define RECCOMENDATION_H_INCLUDED
int IsNotMember(item arr[], int , item element);
void RatingSort(item arr[], int);
int PriorityNotIn(int arr1[25],int arr1_size,item element);
item FindItem(item items[25],int ,char id[10]);
int NotInArray(int num, int arr[], int );



#endif // RECCOMENDATION_H_INCLUDED
