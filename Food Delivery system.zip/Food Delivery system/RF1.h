#ifndef RF1_H_INCLUDED
#define RF1_H_INCLUDED


void DistanceSort(restaurant array[], int size);
void RatingSort(restaurant array[], int size);
void OfferSort(restaurant array[], int size);
int CalcDist(int source_x, int source_y, int dest_x, int dest_y);
int main_rf1(int dest_x,int dest_y);

#endif // RF1_H_INCLUDED
