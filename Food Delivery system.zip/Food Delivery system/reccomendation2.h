#ifndef RECCOMENDATION2_H_INCLUDED
#define RECCOMENDATION2_H_INCLUDED

void AssocSort1(item_asoc all_items[],int );
int InArray(char foodid[10], char arr[100][11], int );
item1 FindItem(item1 items[25],int ,char id[10]);
void main_r2(char menu_id[],char cartid[100][11],int size1,char custid[],char rid[]);



#endif // RECCOMENDATION2_H_INCLUDED
