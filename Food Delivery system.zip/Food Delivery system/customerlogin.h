#ifndef CUSTOMERLOGIN_H_INCLUDED
#define CUSTOMERLOGIN_H_INCLUDED
int reg();
int login(char username[],char pwd[],char custid[],char c_name[]);
int forgot(char name[],char password[]);


#endif // CUSTOMERLOGIN_H_INCLUDED
