#ifndef MENUALTER_H_INCLUDED
#define MENUALTER_H_INCLUDED
void DisplayMenu();
void UpdatePrice(item records[], int);
void DisplayRecords(item records[], int);
void UpdatePrice(item records[], int);
int GetPriority(item arr1[100],int,char food_type[50]);
void AddRecord(item records[], int *);
void DeleteRecord(item records[], int *);




#endif // MENUALTER_H_INCLUDED
