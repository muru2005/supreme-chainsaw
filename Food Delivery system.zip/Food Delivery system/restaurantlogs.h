#ifndef RESTAURANTLOGS_H_INCLUDED
#define RESTAURANTLOGS_H_INCLUDED
int logs(struct restaurant arr[],int i,char menuid[]);
int forgotpassw(struct restaurant arr[],int i);


#endif // RESTAURANTLOGS_H_INCLUDED
